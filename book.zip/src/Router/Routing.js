import React from "react";
import { Route, Routes, BrowserRouter as Router } from "react-router-dom";
import Header from "../Layout/Header";
import ShopPage from "../Pages/Shop/shop";
import Cart from "../Pages/Cart/CartPage";
import Register from "../Pages/Register/Register";
import LoginPage from "../Pages/Login/Login";
import CheckoutPage from "../Pages/Checkout/Checkout";
import BookDetailPage from "../Pages/BookDetail/BookDetail";
import OrderListPage from "../Pages/OrderList/OrderList";
import OrderViewPage from "../Pages/OrderView/OrderView";
function Routing() {
  return (
    <Router>
      <Header />
      <Routes>
        <Route path="/shop/:filterType/:filterValue" element={<ShopPage />} />
        <Route path="/shop" element={<ShopPage />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/book/:bookName" element={<BookDetailPage />} />
        <Route path="/order" element={<OrderListPage />} />
        <Route path="/order" element={<OrderListPage />} />
        <Route path="/order/:orderId" element={<OrderViewPage />} />
      </Routes>
    </Router>
  );
}

export default Routing;
