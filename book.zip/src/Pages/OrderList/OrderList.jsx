import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllOrderList } from "../../Toolkit/orderSlice";
import { Container, CircularProgress, Typography } from "@mui/material";
import OrderList from "../../Components/OrderList";


const OrderListPage = () => {
  const dispatch = useDispatch();
  const { isLoading, error, allOrderList } = useSelector((state) => state.order);

  console.log(isLoading, error, allOrderList);
  

  useEffect(() => {
    dispatch(getAllOrderList());
  }, []);

  return (
    <Container maxWidth='lg' sx={{ py: 4 }}>
      <Typography variant="h4" fontWeight="bold" sx={{ mb: 3 }}>
        Order List
      </Typography>

      {isLoading && <CircularProgress />}
      {error && <Typography color="error">{error}</Typography>}
      
      {!isLoading && allOrderList.length === 0 && (
        <Typography>No orders available.</Typography>
      )}

      {allOrderList.map((order) => (
        <OrderList key={order.id} order={order} />
      ))}
    </Container>
  );
};

export default OrderListPage;
