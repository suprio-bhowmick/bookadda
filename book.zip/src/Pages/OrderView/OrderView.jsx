import React from 'react'

function OrderViewPage() {
  return (
    <div>OrderViewPage</div>
  )
}

export default OrderViewPage