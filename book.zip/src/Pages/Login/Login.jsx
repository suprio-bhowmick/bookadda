import React, { useEffect } from "react";
import {
  Box,
  Card,
  CardContent,
  Container,
  Grid,
  TextField,
  Typography,
  Button,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { userLogin } from "../../Toolkit/authSlice";

function LoginPage() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading, error, isLoggedIn } = useSelector(
    (state) => state.auth
  );
  // console.log(isLoading, userToken)
  // useEffect(() => {
  //   if (userToken && !isLoading) {
  //     navigate("/profile");
      
  //   }
  // }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = (data) => {
    dispatch(userLogin(data));
  };

  // Redirect and show toast on successful login
  useEffect(() => {
    if (isLoggedIn) {
      toast.success("Login successful! Redirecting...", {
        position: "top-right",
        autoClose: 1500, // 1.5 seconds delay
      });

      setTimeout(() => {
        navigate("/dashboard"); // Redirect to dashboard
      }, 1600);
    }
  }, [isLoggedIn, navigate]);

  return (
    <Container maxWidth="xl">
      <Box>
        <Card>
          <CardContent sx={{ padding: 0, paddingBottom: 0 }}>
            <Grid container>
              <Grid item xs={12} md={6}>
                <img
                  style={{ width: "100%", height: "100%" }}
                  src="./assets/image/login.jpg"
                  alt="Login"
                />
              </Grid>
              <Grid item xs={12} md={6} sx={{ padding: "25px" }}>
                <Typography variant="h5" sx={{ marginBottom: "15px" }}>
                  Login
                </Typography>

                <form onSubmit={handleSubmit(onSubmit)}>
                  {/* Mobile Number */}
                  <Box sx={{ marginBottom: 2 }}>
                    <label>Mobile Number</label>
                    <TextField
                      {...register("mobile", {
                        required: "Mobile Number is required",
                        pattern: {
                          value: /^[0-9]{10}$/,
                          message: "Enter a valid 10-digit mobile number",
                        },
                      })}
                      placeholder="Mobile Number"
                      variant="outlined"
                      fullWidth
                      error={!!errors.mobile}
                      helperText={errors.mobile?.message}
                    />
                  </Box>

                  {/* Password */}
                  <Box sx={{ marginBottom: 2 }}>
                    <label>Password</label>
                    <TextField
                      {...register("password", {
                        required: "Password is required",
                        minLength: {
                          value: 6,
                          message: "Password must be at least 6 characters",
                        },
                      })}
                      placeholder="Password"
                      variant="outlined"
                      fullWidth
                      type="password"
                      error={!!errors.password}
                      helperText={errors.password?.message}
                    />
                  </Box>

                  {/* Submit Button */}
                  <Button
                    disabled={isLoading}
                    type="submit"
                    variant="contained"
                    fullWidth
                  >
                    {isLoading ? "Logging in..." : "Login"}
                  </Button>
                  {error && (
                    <Typography color="error" sx={{ marginTop: 2 }}>
                      {error}
                    </Typography>
                  )}
                </form>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      </Box>

      {/* Toast Notification Container */}
      <ToastContainer />
    </Container>
  );
}

export default LoginPage;
