import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Typography,
  IconButton,
  Box,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { updateCart, removeFromCart } from "../../Toolkit/cartSlice";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ModalComponent from "../../Components/ModalComponent"; // Import reusable modal

const CartPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const cart = useSelector((state) => state.cart.cart);
  const userToken = useSelector((state) => state.auth.userToken); // Check if user is logged in
  const [openModal, setOpenModal] = useState(false); // Manage modal state

  // Calculate total price
  const grandTotal = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  const handleCheckout = () => {
    if (userToken) {
      navigate("/checkout"); // If logged in, navigate to checkout
    } else {
      setOpenModal(true); // Show login modal if not logged in
    }
  };

  return (
    <Box sx={{ width: "90%", margin: "auto", mt: 3 }}>
      <Typography variant="h4" gutterBottom align="center">
        Shopping Cart
      </Typography>

      {cart.length === 0 ? (
        <Box sx={{ textAlign: "center", mt: 5 }}>
          <ShoppingCartIcon sx={{ fontSize: 60, color: "gray" }} />
          <Typography variant="h6" color="text.secondary" mt={1}>
            Your cart is empty!
          </Typography>
        </Box>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow sx={{ bgcolor: "#f5f5f5" }}>
                <TableCell>Book</TableCell>
                <TableCell align="center">Price</TableCell>
                <TableCell align="center">Quantity</TableCell>
                <TableCell align="center">Total</TableCell>
                <TableCell align="center">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {cart.map((book) => (
                <TableRow key={book.id}>
                  <TableCell sx={{ display: "flex", alignItems: "center" }}>
                    <img
                      src={book.thumbnail}
                      alt={book.title}
                      width="50"
                      height="70"
                      style={{ marginRight: 10 }}
                    />
                    <Box>
                      <Typography variant="h6">{book.title}</Typography>
                      <Typography component="div" sx={{ fontStyle: "italic" }}>
                        - {book.author}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell align="center">₹ {book.price.toFixed(2)}</TableCell>
                  <TableCell align="center">
                    <IconButton
                      color="primary"
                      onClick={() =>
                        dispatch(updateCart({ id: book.id, type: "INC" }))
                      }
                    >
                      <AddIcon />
                    </IconButton>
                    {book.quantity}
                    <IconButton
                      color="secondary"
                      disabled={book.quantity <= 1}
                      onClick={() =>
                        dispatch(updateCart({ id: book.id, type: "DEC" }))
                      }
                    >
                      <RemoveIcon />
                    </IconButton>
                  </TableCell>
                  <TableCell align="center">
                    ₹ {(book.price * book.quantity).toFixed(2)}
                  </TableCell>
                  <TableCell align="center">
                    <IconButton
                      color="error"
                      onClick={() => dispatch(removeFromCart({ id: book.id }))}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}

      {cart.length > 0 && (
        <Box
          sx={{
            position: "fixed",
            bottom: 20,
            right: 20,
            bgcolor: "#ff9800",
            p: 2,
            borderRadius: "10px",
            boxShadow: 3,
          }}
        >
          <Typography variant="h6" sx={{ color: "white" }}>
            Grand Total: ₹ {grandTotal.toFixed(2)}
          </Typography>
          <Button
            variant="contained"
            color="primary"
            sx={{ mt: 1, width: "100%" }}
            onClick={handleCheckout}
          >
            Proceed to Checkout
          </Button>
        </Box>
      )}

      {/* Reusable Modal for Login Prompt */}
      <ModalComponent
        open={openModal}
        onClose={() => setOpenModal(false)}
        message="You need to log in to proceed to checkout."
        onLogin={() => navigate("/login")}
      />
    </Box>
  );
};

export default CartPage;
