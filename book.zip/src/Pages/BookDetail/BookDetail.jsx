import { Container, Grid, Typography } from "@mui/material";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router-dom";
import { getSingleBook } from "../../Toolkit/bookSlice";

function BookDetailPage() {
  const { bookName } = useParams();
  const dispatch = useDispatch();
  const { singleBook, isLoading } = useSelector((state) => state.books);
  useEffect(() => {
    dispatch(getSingleBook(bookName));
  }, []);
  console.log(singleBook, isLoading);

  return (
    <Container maxWidth="lg">
      <Grid container spacing={2}>
        <Grid item xs={4}>
          <img src={singleBook[0].thumbnail} />
        </Grid>
        <Grid item xs={8}>
          <Typography variant="h4">{singleBook[0].title}</Typography>
          <Typography variant="p">by {singleBook[0].author} (author)</Typography>
        </Grid>
      </Grid>
    </Container>
  );
}

export default BookDetailPage;
