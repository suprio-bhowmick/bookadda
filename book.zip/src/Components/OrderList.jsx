import React from "react";
import {
  Card,
  CardContent,
  Typography,
  Divider,
  Grid,
  Avatar,
  Box,
} from "@mui/material";
import { Image } from "@mui/icons-material";

const OrderList = ({ order }) => {
  return (
    <Card sx={{ mb: 2, p: 2, boxShadow: 3 }}>
      <CardContent>
        <Typography variant="h6" fontWeight="bold">
          Order ID: {order.orderId}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Order Date: {order.orderDate}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Order Grand Total:{" "}
          {(
            order.subTotal +
            (order.subTotal * 18) / 100 -
            order.discount
          ).toFixed(2)}
        </Typography>

        <Divider sx={{ my: 2 }} />

        <Typography variant="subtitle1" fontWeight="bold">
          Ordered Books:
        </Typography>
        <Grid container spacing={2}>
          {order.books.map((book, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Card
                sx={{
                  display: "flex",
                  p: 1,
                  alignItems: "center",
                  boxShadow: 1,
                }}
              >
                <Box
                  component="img"
                  src={book.thumbnail}
                  alt={book.title}
                  sx={{ width: 50, height: 70, mr: 2 }}
                />
                <div>
                  <Typography variant="body1" fontWeight="bold">
                    {book.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    {book.author} - ₹{book.price} x {book.quantity}
                  </Typography>
                </div>
              </Card>
            </Grid>
          ))}
        </Grid>
      </CardContent>
    </Card>
  );
};

export default OrderList;
