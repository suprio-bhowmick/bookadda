import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#6B4226', // Dark Brown (Main Color)
      contrastText: '#ffffff',
    },
    secondary: {
      main: '#C49A6C', // Tan
    },
    background: {
      default: '#F5F1E3', // Light Beige
      paper: '#FFFFFF',
    },
    text: {
      primary: '#1E2022', // Dark Gray for readability
      secondary: '#6B4226', // Brown for accents
    },
    accent: {
      main: '#8C6239', // Cocoa Brown
    },
  },
  typography: {
    fontFamily: "'Poppins', sans-serif",
    h1: { fontSize: '2rem', fontWeight: 700 },
    h2: { fontSize: '1.8rem', fontWeight: 600 },
    body1: { fontSize: '1rem', fontWeight: 400 },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: '8px',
          textTransform: 'none',
        },
      },
    },
  },
});

export default theme;
