export const  base_url = "http://localhost:1000"

export const end_points = {
    books: "/books",
    user: "/user",
    order: "/order",
}